from fastapi import FastAPI
app=FastAPI(title='AI Video Studio API starter')
@app.get('/')
def health():
    return {'ok':True,'video_generation':'not connected','note':'Health check only; never put secrets in frontend files.'}
