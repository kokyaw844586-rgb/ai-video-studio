# AI Video Studio — Android starter

ဒီဗားရှင်းက Prompt ရေး/ပြင်ဆင်ရန်၊ ပုံ preview ပြရန်နှင့် Wan AI ကိုဖွင့်ရန်ဖြစ်သည်။ **ကိုယ်ပိုင် website ထဲမှာ video ကို တိုက်ရိုက်ထုတ်ပေးခြင်း မပါသေးပါ။** Generate နှိပ်လျှင် https://wan.video/ ကိုဖွင့်ပေးသည်။ အဲဒီမှာ prompt ကို paste လုပ်ပြီး video ထုတ်ရပါမည်။ Free credits နှင့် usage limits သည် ဝန်ဆောင်မှုပေါ်မူတည်သည်။

## GitHub Pages
1. ZIP ကို extract လုပ်ပါ.
2. GitHub မှာ `ai-video-studio` repository အသစ်ဖန်တီးပါ.
3. `frontend` folder အတွင်းရှိ `index.html`, `style.css`, `app.js` ကို repository root ထဲတင်ပါ.
4. Repository > Settings > Pages > Deploy from a branch ကိုရွေးပါ.
5. Branch `main`, folder `/(root)` ရွေးပြီး Save နှိပ်ပါ.
6. GitHub Pages URL ပေါ်လာလျှင် ဖွင့်ပါ.

`backend` folder သည် health-check သာဖြစ်ပြီး AI Video API မချိတ်ထားပါ။ Secret များကို frontend သို့မဟုတ် GitHub ထဲ မတင်ပါနှင့်။
